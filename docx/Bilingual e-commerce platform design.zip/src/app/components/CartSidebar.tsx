import { motion, AnimatePresence } from "motion/react";
import { X, Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import { Lang, t } from "./translations";
import { Product } from "./products";

export interface CartItem {
  product: Product;
  qty: number;
}

interface CartSidebarProps {
  lang: Lang;
  items: CartItem[];
  open: boolean;
  onClose: () => void;
  onRemove: (id: string) => void;
  onCheckout: () => void;
}

export function CartSidebar({ lang, items, open, onClose, onRemove, onCheckout }: CartSidebarProps) {
  const tr = t[lang];
  const subtotal = items.reduce((sum, i) => sum + i.product.price * i.qty, 0);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 z-40"
            style={{ background: "rgba(44,24,16,0.4)", backdropFilter: "blur(4px)" }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            className="fixed top-0 bottom-0 z-50 w-full max-w-md flex flex-col shadow-2xl"
            style={{
              [lang === "ar" ? "left" : "right"]: 0,
              background: "var(--background)",
            }}
            initial={{ x: lang === "ar" ? "-100%" : "100%" }}
            animate={{ x: 0 }}
            exit={{ x: lang === "ar" ? "-100%" : "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 36 }}
            dir={tr.dir}
          >
            {/* Header */}
            <div
              className="flex items-center justify-between px-6 py-5 border-b"
              style={{ borderColor: "var(--border)" }}
            >
              <div className="flex items-center gap-3">
                <ShoppingBag size={20} style={{ color: "var(--primary)" }} />
                <h2
                  style={{
                    fontFamily: "var(--font-display)",
                    color: "var(--foreground)",
                    fontSize: "1.25rem",
                  }}
                >
                  {tr.cart.title}
                </h2>
                {items.length > 0 && (
                  <span
                    className="px-2 py-0.5 rounded-full text-xs text-white"
                    style={{ background: "var(--accent)", fontFamily: "var(--font-body)" }}
                  >
                    {items.reduce((s, i) => s + i.qty, 0)} {tr.cart.items}
                  </span>
                )}
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-full transition-colors"
                style={{ color: "var(--foreground)" }}
              >
                <X size={18} />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              <AnimatePresence initial={false}>
                {items.length === 0 ? (
                  <motion.div
                    key="empty"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="flex flex-col items-center justify-center h-full gap-4 py-20"
                  >
                    <div
                      className="w-20 h-20 rounded-full flex items-center justify-center"
                      style={{ background: "var(--secondary)" }}
                    >
                      <ShoppingBag size={32} style={{ color: "var(--muted-foreground)" }} />
                    </div>
                    <p
                      style={{
                        fontFamily: "var(--font-body)",
                        color: "var(--muted-foreground)",
                        fontSize: "0.95rem",
                      }}
                    >
                      {tr.cart.empty}
                    </p>
                  </motion.div>
                ) : (
                  <div className="space-y-4">
                    {items.map(({ product, qty }) => {
                      const name = lang === "en" ? product.nameEn : product.nameAr;
                      const category = lang === "en" ? product.category : product.categoryAr;
                      return (
                        <motion.div
                          key={product.id}
                          layout
                          initial={{ opacity: 0, x: lang === "ar" ? -20 : 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: lang === "ar" ? -40 : 40, height: 0, marginBottom: 0 }}
                          transition={{ duration: 0.28 }}
                          className="flex gap-4 pb-4 border-b"
                          style={{ borderColor: "var(--border)" }}
                        >
                          <div
                            className="w-20 h-24 rounded-lg overflow-hidden shrink-0"
                            style={{ background: "var(--muted)" }}
                          >
                            <img
                              src={product.image}
                              alt={name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p
                              className="text-xs uppercase tracking-widest mb-1"
                              style={{ color: "var(--accent)", fontFamily: "var(--font-body)" }}
                            >
                              {category}
                            </p>
                            <p
                              className="leading-snug mb-2"
                              style={{
                                fontFamily: "var(--font-display)",
                                color: "var(--foreground)",
                                fontSize: "0.95rem",
                              }}
                            >
                              {name}
                            </p>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-1">
                                <span
                                  className="text-xs"
                                  style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                                >
                                  ×{qty}
                                </span>
                                <span
                                  style={{
                                    fontFamily: "var(--font-display)",
                                    color: "var(--primary)",
                                    fontWeight: 600,
                                    fontSize: "1rem",
                                  }}
                                >
                                  &nbsp;${product.price * qty}
                                </span>
                              </div>
                              <button
                                onClick={() => onRemove(product.id)}
                                className="p-1.5 rounded-full transition-colors hover:bg-[var(--muted)]"
                                style={{ color: "var(--muted-foreground)" }}
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                )}
              </AnimatePresence>
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div
                className="px-6 py-5 border-t space-y-4"
                style={{ borderColor: "var(--border)", background: "var(--card)" }}
              >
                {/* Subtotal */}
                <div className="flex items-center justify-between">
                  <span style={{ fontFamily: "var(--font-body)", color: "var(--muted-foreground)", fontSize: "0.9rem" }}>
                    {tr.cart.subtotal}
                  </span>
                  <span
                    style={{
                      fontFamily: "var(--font-display)",
                      color: "var(--foreground)",
                      fontWeight: 700,
                      fontSize: "1.2rem",
                    }}
                  >
                    ${subtotal}
                  </span>
                </div>

                {/* Checkout CTA */}
                <motion.button
                  onClick={onCheckout}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-3.5 rounded-full text-white flex items-center justify-center gap-2"
                  style={{
                    background: "linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%)",
                    fontFamily: "var(--font-body)",
                    fontWeight: 600,
                    fontSize: "0.95rem",
                  }}
                >
                  {tr.cart.checkout}
                  <ArrowRight size={16} />
                </motion.button>

                <button
                  onClick={onClose}
                  className="w-full py-2.5 text-sm text-center"
                  style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                >
                  {tr.cart.continue}
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
