import { motion, AnimatePresence } from "motion/react";
import { ShoppingBag, Globe, LayoutDashboard, ClipboardList, Menu, X } from "lucide-react";
import { useState } from "react";
import { Lang, t } from "./translations";

interface NavbarProps {
  lang: Lang;
  onLangToggle: () => void;
  cartCount: number;
  onCartOpen: () => void;
  currentView: string;
  onNavigate: (view: string) => void;
}

export function Navbar({ lang, onLangToggle, cartCount, onCartOpen, currentView, onNavigate }: NavbarProps) {
  const tr = t[lang];
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks = [
    { key: 'shop', label: tr.nav.shop, view: 'storefront' },
    { key: 'orders', label: tr.nav.orders, view: 'orders' },
    { key: 'admin', label: tr.nav.admin, view: 'admin' },
  ];

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 border-b"
      style={{ background: 'rgba(250,247,242,0.92)', backdropFilter: 'blur(12px)', borderColor: 'var(--border)' }}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Brand */}
        <button
          onClick={() => onNavigate('storefront')}
          className="flex flex-col leading-none cursor-pointer"
          style={{ fontFamily: 'var(--font-display)' }}
        >
          <span style={{ color: 'var(--primary)', fontSize: '1.5rem', fontWeight: 700 }}>{tr.brand}</span>
          <span style={{ color: 'var(--muted-foreground)', fontSize: '0.6rem', letterSpacing: '0.15em', textTransform: 'uppercase', fontFamily: 'var(--font-body)' }}>
            {tr.tagline}
          </span>
        </button>

        {/* Desktop Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.key}
              onClick={() => onNavigate(link.view)}
              className="relative transition-colors duration-200"
              style={{
                color: currentView === link.view ? 'var(--primary)' : 'var(--foreground)',
                fontFamily: 'var(--font-body)',
                fontSize: '0.875rem',
                letterSpacing: '0.05em',
              }}
            >
              {link.label}
              {currentView === link.view && (
                <motion.div
                  layoutId="nav-indicator"
                  className="absolute -bottom-1 left-0 right-0 h-0.5 rounded-full"
                  style={{ background: 'var(--primary)' }}
                />
              )}
            </button>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-4">
          {/* Language Toggle */}
          <motion.button
            onClick={onLangToggle}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border transition-colors"
            style={{
              borderColor: 'var(--border)',
              color: 'var(--muted-foreground)',
              fontFamily: 'var(--font-body)',
              fontSize: '0.75rem',
              background: 'var(--secondary)',
            }}
          >
            <Globe size={13} />
            <span>{lang === 'en' ? 'عربي' : 'English'}</span>
          </motion.button>

          {/* Cart */}
          <motion.button
            onClick={onCartOpen}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="relative p-2 rounded-full"
            style={{ color: 'var(--foreground)' }}
          >
            <ShoppingBag size={20} />
            <AnimatePresence>
              {cartCount > 0 && (
                <motion.span
                  key="badge"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className="absolute -top-1 -right-1 flex items-center justify-center w-4 h-4 rounded-full text-white"
                  style={{ background: 'var(--accent)', fontSize: '0.6rem', fontFamily: 'var(--font-body)', fontWeight: 700 }}
                >
                  {cartCount}
                </motion.span>
              )}
            </AnimatePresence>
          </motion.button>

          {/* Mobile menu */}
          <button
            className="md:hidden p-2"
            style={{ color: 'var(--foreground)' }}
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="md:hidden overflow-hidden border-t"
            style={{ borderColor: 'var(--border)', background: 'var(--background)' }}
          >
            <div className="px-6 py-4 flex flex-col gap-4">
              {navLinks.map((link) => (
                <button
                  key={link.key}
                  onClick={() => { onNavigate(link.view); setMobileOpen(false); }}
                  className="text-left py-1"
                  style={{
                    color: currentView === link.view ? 'var(--primary)' : 'var(--foreground)',
                    fontFamily: 'var(--font-body)',
                    fontWeight: currentView === link.view ? 600 : 400,
                  }}
                >
                  {link.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
