import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { TrendingUp, ShoppingBag, Users, DollarSign, AlertCircle, ChevronRight, LayoutDashboard, Package, UserCircle, Bell } from "lucide-react";
import { Lang, t } from "./translations";

interface AdminDashboardProps {
  lang: Lang;
}

const salesData = [
  { month: "Jan", revenue: 4200, orders: 38 },
  { month: "Feb", revenue: 5800, orders: 51 },
  { month: "Mar", revenue: 7100, orders: 64 },
  { month: "Apr", revenue: 6400, orders: 58 },
  { month: "May", revenue: 8900, orders: 82 },
  { month: "Jun", revenue: 11200, orders: 97 },
  { month: "Jul", revenue: 9700, orders: 88 },
  { month: "Aug", revenue: 13400, orders: 116 },
  { month: "Sep", revenue: 12100, orders: 104 },
  { month: "Oct", revenue: 14800, orders: 128 },
  { month: "Nov", revenue: 18200, orders: 157 },
  { month: "Dec", revenue: 21600, orders: 186 },
];

const topProducts = [
  { name: "Marrakech Vase", nameAr: "مزهرية مراكش", sales: 186, revenue: 16554 },
  { name: "Bedouin Throw", nameAr: "غطاء بدوي", sales: 142, revenue: 20590 },
  { name: "Levant Spices", nameAr: "بهارات الشام", sales: 203, revenue: 9744 },
  { name: "Cedar Box", nameAr: "صندوق أرز", sales: 97, revenue: 6984 },
  { name: "Kilim Cushion", nameAr: "وسادة كليم", sales: 124, revenue: 12152 },
];

const recentOrders = [
  { id: "RW-221847", customer: "Layla Al-Mansouri", date: "Jun 10, 2026", total: 234, status: "delivered" },
  { id: "RW-221846", customer: "Omar Khalil", date: "Jun 10, 2026", total: 89, status: "shipped" },
  { id: "RW-221845", customer: "Fatima Hassan", date: "Jun 9, 2026", total: 145, status: "processing" },
  { id: "RW-221844", customer: "Ahmed Nasser", date: "Jun 9, 2026", total: 330, status: "pending" },
  { id: "RW-221843", customer: "Sara Qasim", date: "Jun 8, 2026", total: 72, status: "delivered" },
];

const STATUS_COLORS: Record<string, string> = {
  pending: "#D4852A",
  processing: "#4a90d9",
  shipped: "#7a5c9e",
  delivered: "#4a7c59",
};

function StatCard({ icon: Icon, label, value, delta, delay }: {
  icon: React.ElementType; label: string; value: string; delta: string; delay: number;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      whileHover={{ y: -3 }}
      className="rounded-2xl p-5 flex flex-col gap-4"
      style={{ background: "var(--card)", border: "1px solid var(--border)" }}
    >
      <div className="flex items-start justify-between">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{ background: "var(--secondary)" }}
        >
          <Icon size={18} style={{ color: "var(--primary)" }} />
        </div>
        <span
          className="text-xs px-2 py-1 rounded-full"
          style={{
            background: "rgba(74,124,89,0.12)",
            color: "#4a7c59",
            fontFamily: "var(--font-body)",
          }}
        >
          {delta}
        </span>
      </div>
      <div>
        <p className="text-xs uppercase tracking-wide mb-1" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
          {label}
        </p>
        <p style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "1.7rem", fontWeight: 700, lineHeight: 1 }}>
          {value}
        </p>
      </div>
    </motion.div>
  );
}

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div
      className="rounded-xl px-4 py-3 shadow-xl"
      style={{ background: "var(--card)", border: "1px solid var(--border)", fontFamily: "var(--font-body)" }}
    >
      <p className="text-xs mb-1" style={{ color: "var(--muted-foreground)" }}>{label}</p>
      {payload.map((p: any) => (
        <p key={p.dataKey} className="text-sm font-semibold" style={{ color: p.color }}>
          {p.dataKey === "revenue" ? `$${p.value.toLocaleString()}` : `${p.value} orders`}
        </p>
      ))}
    </div>
  );
}

type AdminTab = "overview" | "orders" | "products" | "customers";

export function AdminDashboard({ lang }: AdminDashboardProps) {
  const tr = t[lang];
  const [activeTab, setActiveTab] = useState<AdminTab>("overview");
  const [chartHovered, setChartHovered] = useState(false);

  const navItems = [
    { key: "overview" as AdminTab, label: tr.admin.overview, icon: LayoutDashboard },
    { key: "orders" as AdminTab, label: tr.admin.orders, icon: ShoppingBag },
    { key: "products" as AdminTab, label: tr.admin.products, icon: Package },
    { key: "customers" as AdminTab, label: tr.admin.customers, icon: UserCircle },
  ];

  const getStatusLabel = (status: string) => {
    const map: Record<string, string> = {
      pending: tr.admin.pending,
      processing: tr.admin.processing,
      shipped: tr.admin.shipped,
      delivered: tr.admin.delivered,
    };
    return map[status] ?? status;
  };

  return (
    <div
      className="min-h-screen flex"
      style={{ background: "var(--background)" }}
      dir={tr.dir}
    >
      {/* Sidebar */}
      <div
        className="hidden md:flex flex-col w-60 shrink-0 border-r"
        style={{ borderColor: "var(--border)", background: "var(--card)" }}
      >
        {/* Brand */}
        <div className="px-5 py-5 border-b" style={{ borderColor: "var(--border)" }}>
          <p style={{ fontFamily: "var(--font-display)", color: "var(--primary)", fontSize: "1.3rem", fontWeight: 700 }}>
            {tr.brand}
          </p>
          <p className="text-xs mt-0.5" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
            {tr.admin.title}
          </p>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navItems.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key)}
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-colors text-sm"
              style={{
                background: activeTab === key ? "var(--primary)" : "transparent",
                color: activeTab === key ? "var(--primary-foreground)" : "var(--muted-foreground)",
                fontFamily: "var(--font-body)",
                fontWeight: activeTab === key ? 600 : 400,
                textAlign: lang === "ar" ? "right" : "left",
              }}
            >
              <Icon size={16} />
              {label}
            </button>
          ))}
        </nav>

        {/* Alert badge */}
        <div className="px-3 pb-5">
          <div
            className="flex items-center gap-3 px-3 py-3 rounded-xl"
            style={{ background: "rgba(212,133,42,0.12)", border: "1px solid rgba(212,133,42,0.3)" }}
          >
            <AlertCircle size={16} style={{ color: "var(--accent)", flexShrink: 0 }} />
            <div>
              <p className="text-xs font-semibold" style={{ color: "var(--accent)", fontFamily: "var(--font-body)" }}>
                {lang === "en" ? "4 orders pending" : "٤ طلبات معلقة"}
              </p>
              <p className="text-xs" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
                {lang === "en" ? "Needs attention" : "تحتاج إلى اهتمام"}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main */}
      <div className="flex-1 overflow-y-auto">
        {/* Top bar */}
        <div
          className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b"
          style={{
            background: "rgba(250,247,242,0.95)",
            backdropFilter: "blur(12px)",
            borderColor: "var(--border)",
          }}
        >
          <div>
            <h1
              style={{
                fontFamily: "var(--font-display)",
                color: "var(--foreground)",
                fontSize: "1.3rem",
                fontWeight: 600,
              }}
            >
              {navItems.find((n) => n.key === activeTab)?.label}
            </h1>
            <p className="text-xs" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
              {lang === "en" ? "June 11, 2026" : "١١ يونيو ٢٠٢٦"}
            </p>
          </div>
          <button
            className="relative p-2 rounded-full"
            style={{ background: "var(--secondary)" }}
          >
            <Bell size={16} style={{ color: "var(--foreground)" }} />
            <span
              className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 rounded-full flex items-center justify-center text-white"
              style={{ background: "var(--accent)", fontSize: "0.55rem", fontFamily: "var(--font-body)" }}
            >
              4
            </span>
          </button>
        </div>

        <div className="p-6 max-w-5xl">
          {/* Mobile tab bar */}
          <div className="flex gap-2 mb-6 md:hidden overflow-x-auto">
            {navItems.map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className="px-4 py-2 rounded-full text-xs whitespace-nowrap"
                style={{
                  background: activeTab === key ? "var(--primary)" : "var(--secondary)",
                  color: activeTab === key ? "white" : "var(--foreground)",
                  fontFamily: "var(--font-body)",
                  fontWeight: activeTab === key ? 600 : 400,
                }}
              >
                {label}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {activeTab === "overview" && (
              <motion.div
                key="overview"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                {/* Stat cards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <StatCard icon={DollarSign} label={tr.admin.revenue} value="$133.6k" delta="+18%" delay={0} />
                  <StatCard icon={ShoppingBag} label={tr.admin.ordersCount} value="1,069" delta="+12%" delay={0.08} />
                  <StatCard icon={Users} label={tr.admin.customersCount} value="847" delta="+9%" delay={0.16} />
                  <StatCard icon={TrendingUp} label={tr.admin.avgOrder} value="$125" delta="+5%" delay={0.24} />
                </div>

                {/* Charts row */}
                <div className="grid lg:grid-cols-[2fr_1fr] gap-4">
                  {/* Area chart */}
                  <motion.div
                    className="rounded-2xl p-5"
                    style={{ background: "var(--card)", border: "1px solid var(--border)" }}
                    onHoverStart={() => setChartHovered(true)}
                    onHoverEnd={() => setChartHovered(false)}
                  >
                    <div className="flex items-center justify-between mb-5">
                      <h3
                        style={{
                          fontFamily: "var(--font-display)",
                          color: "var(--foreground)",
                          fontSize: "1rem",
                        }}
                      >
                        {tr.admin.salesChart}
                      </h3>
                      <span
                        className="text-xs px-2 py-1 rounded-full"
                        style={{ background: "var(--secondary)", color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                      >
                        2026
                      </span>
                    </div>
                    <motion.div animate={{ opacity: chartHovered ? 1 : 0.85 }} transition={{ duration: 0.2 }}>
                      <ResponsiveContainer width="100%" height={200}>
                        <AreaChart data={salesData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                          <defs>
                            <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="var(--primary)" stopOpacity={0.3} />
                              <stop offset="95%" stopColor="var(--primary)" stopOpacity={0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                          <XAxis
                            dataKey="month"
                            tick={{ fontSize: 10, fill: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                            axisLine={false}
                            tickLine={false}
                          />
                          <YAxis
                            tick={{ fontSize: 10, fill: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                            axisLine={false}
                            tickLine={false}
                          />
                          <Tooltip content={<CustomTooltip />} />
                          <Area
                            type="monotone"
                            dataKey="revenue"
                            stroke="var(--primary)"
                            strokeWidth={2}
                            fill="url(#revenueGrad)"
                            dot={false}
                            activeDot={{ r: 5, fill: "var(--accent)", strokeWidth: 0 }}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </motion.div>
                  </motion.div>

                  {/* Bar chart — top products */}
                  <motion.div
                    className="rounded-2xl p-5"
                    style={{ background: "var(--card)", border: "1px solid var(--border)" }}
                  >
                    <h3
                      className="mb-5"
                      style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "1rem" }}
                    >
                      {tr.admin.topProducts}
                    </h3>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={topProducts} layout="vertical" margin={{ left: -10, right: 10 }}>
                        <XAxis type="number" hide />
                        <YAxis
                          dataKey={lang === "en" ? "name" : "nameAr"}
                          type="category"
                          width={80}
                          tick={{ fontSize: 9, fill: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                          axisLine={false}
                          tickLine={false}
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Bar
                          dataKey="sales"
                          fill="var(--accent)"
                          radius={[0, 4, 4, 0]}
                          maxBarSize={16}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </motion.div>
                </div>

                {/* Recent orders table */}
                <div
                  className="rounded-2xl overflow-hidden"
                  style={{ border: "1px solid var(--border)", background: "var(--card)" }}
                >
                  <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: "var(--border)" }}>
                    <h3 style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "1rem" }}>
                      {tr.admin.recentOrders}
                    </h3>
                    <button className="text-xs flex items-center gap-1" style={{ color: "var(--accent)", fontFamily: "var(--font-body)" }}>
                      {lang === "en" ? "View all" : "عرض الكل"} <ChevronRight size={12} />
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr style={{ background: "var(--secondary)" }}>
                          {["Order", "Customer", "Date", "Total", "Status"].map((h) => (
                            <th
                              key={h}
                              className="px-5 py-3 text-xs uppercase tracking-wider text-left"
                              style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", fontWeight: 500 }}
                            >
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {recentOrders.map((order, i) => (
                          <motion.tr
                            key={order.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: i * 0.06 }}
                            className="border-b last:border-0"
                            style={{ borderColor: "var(--border)" }}
                          >
                            <td
                              className="px-5 py-3.5"
                              style={{ fontFamily: "var(--font-body)", color: "var(--primary)", fontWeight: 600, fontSize: "0.8rem" }}
                            >
                              {order.id}
                            </td>
                            <td
                              className="px-5 py-3.5"
                              style={{ fontFamily: "var(--font-body)", color: "var(--foreground)", fontSize: "0.875rem" }}
                            >
                              {order.customer}
                            </td>
                            <td
                              className="px-5 py-3.5"
                              style={{ fontFamily: "var(--font-body)", color: "var(--muted-foreground)", fontSize: "0.8rem" }}
                            >
                              {order.date}
                            </td>
                            <td
                              className="px-5 py-3.5"
                              style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontWeight: 600 }}
                            >
                              ${order.total}
                            </td>
                            <td className="px-5 py-3.5">
                              <span
                                className="px-2.5 py-1 rounded-full text-xs"
                                style={{
                                  background: `${STATUS_COLORS[order.status]}18`,
                                  color: STATUS_COLORS[order.status],
                                  fontFamily: "var(--font-body)",
                                  fontWeight: 600,
                                }}
                              >
                                {getStatusLabel(order.status)}
                              </span>
                            </td>
                          </motion.tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab !== "overview" && (
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex flex-col items-center justify-center py-32 gap-4"
              >
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center"
                  style={{ background: "var(--secondary)" }}
                >
                  {(() => {
                    const Icon = navItems.find((n) => n.key === activeTab)?.icon ?? LayoutDashboard;
                    return <Icon size={28} style={{ color: "var(--primary)" }} />;
                  })()}
                </div>
                <p style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "1.1rem" }}>
                  {navItems.find((n) => n.key === activeTab)?.label}
                </p>
                <p style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", fontSize: "0.875rem" }}>
                  {lang === "en" ? "Section coming soon" : "القسم قيد الإنشاء"}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
