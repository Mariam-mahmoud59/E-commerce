export interface Product {
  id: string;
  nameEn: string;
  nameAr: string;
  descriptionEn: string;
  descriptionAr: string;
  price: number;
  currency: string;
  image: string;
  category: string;
  categoryAr: string;
  origin: string;
  originAr: string;
  material: string;
  materialAr: string;
  sku: string;
  rating: number;
  reviews: number;
  inStock: boolean;
}

export const products: Product[] = [
  {
    id: 'p1',
    nameEn: 'Marrakech Ochre Vase',
    nameAr: 'مزهرية مراكش الذهبية',
    descriptionEn: 'Hand-thrown on the wheel by master ceramicists in Fez, this vase showcases the rich ochre glazes of North African tradition. Each piece is unique, bearing the fingerprints of its maker.',
    descriptionAr: 'صُنعت يدوياً على العجلة من قِبَل أساتذة الخزف في فاس، تُبرز هذه المزهرية الطلاءات الذهبية الغنية للتراث الشمال أفريقي. كل قطعة فريدة من نوعها.',
    price: 89,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1760402327535-85a771fb034c?w=600&h=700&fit=crop&auto=format',
    category: 'Ceramics',
    categoryAr: 'سيراميك',
    origin: 'Fez, Morocco',
    originAr: 'فاس، المغرب',
    material: 'Stoneware clay',
    materialAr: 'طين الحجر',
    sku: 'CER-001',
    rating: 4.8,
    reviews: 124,
    inStock: true,
  },
  {
    id: 'p2',
    nameEn: 'Bedouin Woven Throw',
    nameAr: 'غطاء بدوي منسوج',
    descriptionEn: 'Woven by Bedouin artisans using traditional horizontal looms, this throw brings the warmth of the desert into your home. Made from hand-spun wool in natural earth tones.',
    descriptionAr: 'منسوج من قِبَل حرفيين بدويين باستخدام الأنوال الأفقية التقليدية، يجلب هذا الغطاء دفء الصحراء إلى منزلك. مصنوع من الصوف المغزول يدوياً.',
    price: 145,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1619459074324-33d5f591c53e?w=600&h=700&fit=crop&auto=format',
    category: 'Textiles',
    categoryAr: 'منسوجات',
    origin: 'Jordan',
    originAr: 'الأردن',
    material: 'Hand-spun wool',
    materialAr: 'صوف مغزول يدوياً',
    sku: 'TEX-004',
    rating: 4.9,
    reviews: 87,
    inStock: true,
  },
  {
    id: 'p3',
    nameEn: 'Levant Spice Collection',
    nameAr: 'مجموعة بهارات الشام',
    descriptionEn: 'A curated selection of seven traditional Levantine spices, including sumac, za\'atar, and baharat. Sourced directly from family farms and stone-ground using traditional methods.',
    descriptionAr: 'مجموعة مختارة من سبعة بهارات شامية تقليدية، تشمل السماق والزعتر والبهارات. مصدرها مزارع عائلية وتُطحن بالحجارة التقليدية.',
    price: 48,
    currency: 'USD',
    image: 'https://images.unsplash.com/flagged/photo-1553617569-8ef7a8da3146?w=600&h=700&fit=crop&auto=format',
    category: 'Spices',
    categoryAr: 'توابل',
    origin: 'Lebanon & Syria',
    originAr: 'لبنان وسوريا',
    material: 'Organic spices',
    materialAr: 'بهارات عضوية',
    sku: 'SPC-012',
    rating: 4.7,
    reviews: 203,
    inStock: true,
  },
  {
    id: 'p4',
    nameEn: 'Cedar Incense Box',
    nameAr: 'صندوق بخور الأرز',
    descriptionEn: 'Hand-carved from Lebanese cedar wood, this incense box features intricate geometric patterns. The natural cedar fragrance adds an additional layer of sensory richness.',
    descriptionAr: 'منحوت يدوياً من خشب الأرز اللبناني، يتميز هذا الصندوق بأنماط هندسية معقدة. تضيف رائحة الأرز الطبيعية ثراءً حسياً إضافياً.',
    price: 72,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1772442363824-7dec515e859b?w=600&h=700&fit=crop&auto=format',
    category: 'Woodwork',
    categoryAr: 'خشب',
    origin: 'Lebanon',
    originAr: 'لبنان',
    material: 'Lebanese Cedar',
    materialAr: 'أرز لبناني',
    sku: 'WOD-007',
    rating: 4.6,
    reviews: 56,
    inStock: true,
  },
  {
    id: 'p5',
    nameEn: 'Anatolian Kilim Cushion',
    nameAr: 'وسادة كليم الأناضول',
    descriptionEn: 'Crafted from vintage Anatolian kilim fragments, each cushion cover is a one-of-a-kind piece of wearable history. Features traditional geometric motifs in warm amber and rust.',
    descriptionAr: 'مصنوعة من شظايا كليم أناضولي عتيق، كل غطاء وسادة قطعة فريدة من التاريخ. تتميز بزخارف هندسية تقليدية باللونين العنبري والصدئي.',
    price: 98,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1624628795660-a24ce3673add?w=600&h=700&fit=crop&auto=format',
    category: 'Textiles',
    categoryAr: 'منسوجات',
    origin: 'Turkey',
    originAr: 'تركيا',
    material: 'Antique kilim wool',
    materialAr: 'صوف كليم عتيق',
    sku: 'TEX-009',
    rating: 4.9,
    reviews: 142,
    inStock: true,
  },
  {
    id: 'p6',
    nameEn: 'Damascene Silver Ring',
    nameAr: 'خاتم دمشقي فضي',
    descriptionEn: 'Forged by a third-generation silversmith in Damascus, this ring showcases the ancient art of damascening — inlaying gold wire into oxidized silver to create floral patterns.',
    descriptionAr: 'صُهر من قِبَل صائغ فضة من الجيل الثالث في دمشق، يُعرض هذا الخاتم فن التزيين الدمشقي العريق بتطعيم السلك الذهبي في الفضة المؤكسدة.',
    price: 185,
    currency: 'USD',
    image: 'https://images.unsplash.com/photo-1772442363825-f2cb44fb73ad?w=600&h=700&fit=crop&auto=format',
    category: 'Jewelry',
    categoryAr: 'مجوهرات',
    origin: 'Damascus, Syria',
    originAr: 'دمشق، سوريا',
    material: 'Sterling silver & 18k gold',
    materialAr: 'فضة إسترلينية وذهب 18 قيراطاً',
    sku: 'JWL-003',
    rating: 5.0,
    reviews: 34,
    inStock: false,
  },
];
