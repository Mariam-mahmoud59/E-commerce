import { useState, useRef } from "react";
import { motion, AnimatePresence, useScroll, useTransform } from "motion/react";
import { Star, ArrowRight, ChevronRight } from "lucide-react";
import { Lang, t } from "./translations";
import { products, Product } from "./products";

interface StorefrontProps {
  lang: Lang;
  onProductSelect: (p: Product) => void;
  onAddToCart: (p: Product) => void;
  cartAnimTarget?: { x: number; y: number };
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          size={11}
          fill={s <= Math.round(rating) ? "var(--accent)" : "none"}
          stroke={s <= Math.round(rating) ? "var(--accent)" : "var(--muted-foreground)"}
        />
      ))}
    </div>
  );
}

function ProductCard({
  product,
  lang,
  onSelect,
  onAddToCart,
}: {
  product: Product;
  lang: Lang;
  onSelect: (p: Product) => void;
  onAddToCart: (p: Product) => void;
}) {
  const tr = t[lang];
  const [hovered, setHovered] = useState(false);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [adding, setAdding] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const name = lang === "en" ? product.nameEn : product.nameAr;
  const category = lang === "en" ? product.category : product.categoryAr;

  function handleMouseMove(e: React.MouseEvent<HTMLDivElement>) {
    const el = cardRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = ((e.clientY - rect.top) / rect.height - 0.5) * 10;
    const y = -((e.clientX - rect.left) / rect.width - 0.5) * 10;
    setTilt({ x, y });
  }

  function handleMouseLeave() {
    setHovered(false);
    setTilt({ x: 0, y: 0 });
  }

  async function handleAdd(e: React.MouseEvent) {
    e.stopPropagation();
    if (!product.inStock || adding) return;
    setAdding(true);
    onAddToCart(product);
    setTimeout(() => setAdding(false), 1600);
  }

  return (
    <motion.div
      ref={cardRef}
      layout
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 24 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      style={{
        rotateX: hovered ? tilt.x : 0,
        rotateY: hovered ? tilt.y : 0,
        transformPerspective: 800,
        transformStyle: "preserve-3d",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={() => onSelect(product)}
      className="cursor-pointer group relative rounded-xl overflow-hidden"
      style={{ background: "var(--card)" } as React.CSSProperties}
    >
      {/* Image */}
      <div className="relative overflow-hidden" style={{ aspectRatio: "3/4" }}>
        <motion.img
          src={product.image}
          alt={name}
          className="w-full h-full object-cover"
          animate={{ scale: hovered ? 1.06 : 1 }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        />

        {/* Out of stock overlay */}
        {!product.inStock && (
          <div
            className="absolute inset-0 flex items-center justify-center"
            style={{ background: "rgba(250,247,242,0.6)", backdropFilter: "blur(2px)" }}
          >
            <span
              className="px-4 py-1.5 rounded-full text-xs uppercase tracking-widest"
              style={{
                background: "var(--muted)",
                color: "var(--muted-foreground)",
                fontFamily: "var(--font-body)",
              }}
            >
              {tr.product.outOfStock}
            </span>
          </div>
        )}

        {/* Hover overlay — unfurls from bottom */}
        <AnimatePresence>
          {hovered && product.inStock && (
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
              className="absolute inset-x-0 bottom-0 p-4"
              style={{
                background:
                  "linear-gradient(to top, rgba(44,24,16,0.88) 0%, rgba(44,24,16,0.4) 70%, transparent 100%)",
              }}
            >
              <motion.button
                onClick={handleAdd}
                whileTap={{ scale: 0.96 }}
                animate={
                  adding
                    ? { backgroundColor: "#4a7c59", scale: [1, 1.04, 1] }
                    : { backgroundColor: "var(--accent)" }
                }
                transition={{ duration: 0.4 }}
                className="w-full py-2.5 rounded-lg text-sm text-white relative overflow-hidden"
                style={{ fontFamily: "var(--font-body)", fontWeight: 600 }}
              >
                <AnimatePresence mode="wait">
                  {adding ? (
                    <motion.span
                      key="added"
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                    >
                      ✓ {tr.product.addedToCart}
                    </motion.span>
                  ) : (
                    <motion.span
                      key="add"
                      initial={{ opacity: 0, y: 6 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -6 }}
                    >
                      {tr.product.addToCart}
                    </motion.span>
                  )}
                </AnimatePresence>
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Info */}
      <div className="p-4">
        <p
          className="text-xs uppercase tracking-widest mb-1"
          style={{ color: "var(--accent)", fontFamily: "var(--font-body)" }}
        >
          {category}
        </p>
        <h3
          className="mb-1 leading-snug"
          style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "1rem" }}
        >
          {name}
        </h3>
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center gap-2">
            <StarRating rating={product.rating} />
            <span
              className="text-xs"
              style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
            >
              ({product.reviews})
            </span>
          </div>
          <span
            style={{
              color: "var(--primary)",
              fontFamily: "var(--font-display)",
              fontWeight: 600,
              fontSize: "1.05rem",
            }}
          >
            ${product.price}
          </span>
        </div>
      </div>
    </motion.div>
  );
}

export function Storefront({ lang, onProductSelect, onAddToCart }: StorefrontProps) {
  const tr = t[lang];
  const [activeCategory, setActiveCategory] = useState(0);
  const heroRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ["start start", "end start"] });
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 80]);
  const heroOpacity = useTransform(scrollYProgress, [0, 0.6], [1, 0]);

  const categories = tr.categories;
  const filtered =
    activeCategory === 0
      ? products
      : products.filter((p) => {
          const catEn = t.en.categories[activeCategory];
          return p.category === catEn;
        });

  return (
    <div style={{ background: "var(--background)" }}>
      {/* Hero */}
      <div
        ref={heroRef}
        className="relative overflow-hidden flex items-center"
        style={{ minHeight: "100vh", paddingTop: "4rem" }}
      >
        {/* Background image */}
        <motion.div className="absolute inset-0" style={{ y: heroY }}>
          <img
            src="https://images.unsplash.com/photo-1777499576432-28cb3ff31e70?w=1400&h=900&fit=crop&auto=format"
            alt="artisan interior"
            className="w-full h-full object-cover"
            style={{ filter: "brightness(0.55) saturate(0.9)" }}
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(135deg, rgba(44,24,16,0.65) 0%, rgba(196,98,45,0.25) 60%, transparent 100%)",
            }}
          />
        </motion.div>

        {/* Hero content */}
        <motion.div
          className="relative z-10 max-w-7xl mx-auto px-6 w-full"
          style={{ opacity: heroOpacity }}
        >
          <div className="max-w-xl" dir={tr.dir}>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="mb-4 uppercase tracking-[0.25em] text-xs"
              style={{ color: "var(--accent)", fontFamily: "var(--font-body)" }}
            >
              {lang === "en" ? "New Collection — 2026" : "مجموعة جديدة — ٢٠٢٦"}
            </motion.p>
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              className="text-white mb-6"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(2.8rem, 6vw, 5rem)",
                fontWeight: 700,
                lineHeight: 1.1,
                whiteSpace: "pre-line",
              }}
            >
              {tr.hero.title}
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.35 }}
              className="mb-10 leading-relaxed"
              style={{
                color: "rgba(250,247,242,0.82)",
                fontFamily: "var(--font-body)",
                fontSize: "1.05rem",
                maxWidth: "36ch",
              }}
            >
              {tr.hero.subtitle}
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex items-center gap-4 flex-wrap"
            >
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2 px-8 py-3.5 rounded-full text-white text-sm"
                style={{
                  background: "var(--accent)",
                  fontFamily: "var(--font-body)",
                  fontWeight: 600,
                  letterSpacing: "0.04em",
                }}
                onClick={() => {
                  document.getElementById("products-section")?.scrollIntoView({ behavior: "smooth" });
                }}
              >
                {tr.hero.cta}
                <ArrowRight size={15} />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2 px-6 py-3.5 rounded-full text-sm"
                style={{
                  border: "1px solid rgba(250,247,242,0.5)",
                  color: "rgba(250,247,242,0.9)",
                  fontFamily: "var(--font-body)",
                }}
              >
                {tr.hero.secondary}
              </motion.button>
            </motion.div>
          </div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
        >
          <div className="w-px h-12" style={{ background: "rgba(250,247,242,0.4)" }} />
          <div className="w-1 h-1 rounded-full" style={{ background: "rgba(250,247,242,0.6)" }} />
        </motion.div>
      </div>

      {/* Products Section */}
      <div id="products-section" className="max-w-7xl mx-auto px-6 py-20" dir={tr.dir}>
        {/* Category Filter */}
        <div className="flex items-center gap-3 mb-12 overflow-x-auto pb-2 flex-wrap">
          {categories.map((cat, i) => (
            <motion.button
              key={cat}
              onClick={() => setActiveCategory(i)}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className="relative px-5 py-2 rounded-full text-sm transition-colors whitespace-nowrap"
              style={{
                fontFamily: "var(--font-body)",
                color: activeCategory === i ? "var(--primary-foreground)" : "var(--foreground)",
                background: activeCategory === i ? "var(--primary)" : "var(--secondary)",
                fontWeight: activeCategory === i ? 600 : 400,
              }}
            >
              {cat}
            </motion.button>
          ))}
        </div>

        {/* Grid */}
        <motion.div
          layout
          className="grid gap-6"
          style={{ gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))" }}
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                lang={lang}
                onSelect={onProductSelect}
                onAddToCart={onAddToCart}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Marquee banner */}
      <div
        className="py-5 overflow-hidden"
        style={{ background: "var(--primary)", borderTop: "1px solid rgba(255,255,255,0.1)" }}
      >
        <motion.div
          className="flex gap-12 whitespace-nowrap"
          animate={{ x: lang === "ar" ? ["0%", "50%"] : ["0%", "-50%"] }}
          transition={{ duration: 24, ease: "linear", repeat: Infinity }}
        >
          {Array.from({ length: 8 }).map((_, i) => (
            <span
              key={i}
              className="text-sm uppercase tracking-widest"
              style={{ color: "rgba(250,247,242,0.75)", fontFamily: "var(--font-body)" }}
            >
              {lang === "en"
                ? "✦ Handcrafted Heritage  ✦ Authentic Artisans  ✦ Ethically Sourced"
                : "✦ تراث يدوي  ✦ حرفيون أصيلون  ✦ مصادر أخلاقية"}
            </span>
          ))}
        </motion.div>
      </div>

      {/* Editorial feature strip */}
      <div className="max-w-7xl mx-auto px-6 py-20" dir={tr.dir}>
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p
              className="uppercase tracking-widest text-xs mb-4"
              style={{ color: "var(--accent)", fontFamily: "var(--font-body)" }}
            >
              {lang === "en" ? "Our Philosophy" : "فلسفتنا"}
            </p>
            <h2
              className="mb-6 leading-tight"
              style={{
                fontFamily: "var(--font-display)",
                fontSize: "clamp(1.8rem, 3.5vw, 2.8rem)",
                color: "var(--foreground)",
              }}
            >
              {lang === "en"
                ? "Where ancient craft meets modern living"
                : "حيث يلتقي الحرف القديم بالحياة العصرية"}
            </h2>
            <p
              className="leading-relaxed mb-8"
              style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", maxWidth: "44ch" }}
            >
              {lang === "en"
                ? "Every piece in our collection is sourced directly from master artisans across the Arab world — families who have passed their craft through generations. We pay fair prices, tell their stories, and bring their work to the world."
                : "كل قطعة في مجموعتنا مصدرها مباشرة من أساتذة الحرف في العالم العربي — عائلات توارثت حرفتها عبر الأجيال. ندفع أسعاراً عادلة، ونروي قصصهم، ونجلب أعمالهم إلى العالم."}
            </p>
            <button
              className="flex items-center gap-2 text-sm"
              style={{ color: "var(--primary)", fontFamily: "var(--font-body)", fontWeight: 600 }}
            >
              {lang === "en" ? "Meet the Artisans" : "تعرف على الحرفيين"}
              <ChevronRight size={15} />
            </button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <img
              src="https://images.unsplash.com/photo-1594332495179-d979bcd18142?w=400&h=500&fit=crop&auto=format"
              alt="artisan textile"
              className="rounded-xl object-cover w-full"
              style={{ aspectRatio: "4/5" }}
            />
            <img
              src="https://images.unsplash.com/photo-1681817009639-9103dc524813?w=400&h=500&fit=crop&auto=format"
              alt="spice market"
              className="rounded-xl object-cover w-full mt-8"
              style={{ aspectRatio: "4/5" }}
            />
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer
        className="border-t py-10 px-6"
        style={{ borderColor: "var(--border)", background: "var(--card)" }}
        dir={tr.dir}
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <span
            style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", fontSize: "0.8rem" }}
          >
            {tr.footer.rights}
          </span>
          <div className="flex gap-6">
            {[tr.footer.privacy, tr.footer.terms].map((link) => (
              <button
                key={link}
                className="text-xs hover:underline"
                style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
              >
                {link}
              </button>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}
