import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Package, Truck, CheckCircle, Clock, ChevronDown, MapPin, ExternalLink } from "lucide-react";
import { Lang, t } from "./translations";

interface OrderHistoryProps {
  lang: Lang;
}

const STATUS_STEPS = ["pending", "processing", "shipped", "delivered"] as const;
type OrderStatus = (typeof STATUS_STEPS)[number];

interface Order {
  id: string;
  date: string;
  total: number;
  status: OrderStatus;
  isActive: boolean;
  items: { name: string; nameAr: string; qty: number; price: number; image: string }[];
  timeline: { status: OrderStatus; date: string; note: string; noteAr: string }[];
}

const ORDERS: Order[] = [
  {
    id: "RW-221847",
    date: "Jun 10, 2026",
    total: 234,
    status: "delivered",
    isActive: false,
    items: [
      { name: "Marrakech Ochre Vase", nameAr: "مزهرية مراكش الذهبية", qty: 1, price: 89, image: "https://images.unsplash.com/photo-1760402327535-85a771fb034c?w=80&h=80&fit=crop" },
      { name: "Bedouin Woven Throw", nameAr: "غطاء بدوي منسوج", qty: 1, price: 145, image: "https://images.unsplash.com/photo-1619459074324-33d5f591c53e?w=80&h=80&fit=crop" },
    ],
    timeline: [
      { status: "pending", date: "Jun 7, 2026 · 09:14", note: "Order received and confirmed", noteAr: "تم استلام الطلب وتأكيده" },
      { status: "processing", date: "Jun 8, 2026 · 11:30", note: "Artisan preparing your item", noteAr: "الحرفي يجهز طلبك" },
      { status: "shipped", date: "Jun 9, 2026 · 08:00", note: "Shipped via DHL Express", noteAr: "تم الشحن عبر DHL Express" },
      { status: "delivered", date: "Jun 10, 2026 · 14:22", note: "Delivered to your address", noteAr: "تم التسليم إلى عنوانك" },
    ],
  },
  {
    id: "RW-221845",
    date: "Jun 9, 2026",
    total: 145,
    status: "shipped",
    isActive: true,
    items: [
      { name: "Bedouin Woven Throw", nameAr: "غطاء بدوي منسوج", qty: 1, price: 145, image: "https://images.unsplash.com/photo-1619459074324-33d5f591c53e?w=80&h=80&fit=crop" },
    ],
    timeline: [
      { status: "pending", date: "Jun 7, 2026 · 16:02", note: "Order received and confirmed", noteAr: "تم استلام الطلب وتأكيده" },
      { status: "processing", date: "Jun 8, 2026 · 09:15", note: "Artisan preparing your item", noteAr: "الحرفي يجهز طلبك" },
      { status: "shipped", date: "Jun 9, 2026 · 10:44", note: "In transit — estimated delivery Jun 12", noteAr: "في الطريق — التسليم المتوقع ١٢ يونيو" },
    ],
  },
  {
    id: "RW-221843",
    date: "Jun 4, 2026",
    total: 48,
    status: "delivered",
    isActive: false,
    items: [
      { name: "Levant Spice Collection", nameAr: "مجموعة بهارات الشام", qty: 1, price: 48, image: "https://images.unsplash.com/flagged/photo-1553617569-8ef7a8da3146?w=80&h=80&fit=crop" },
    ],
    timeline: [
      { status: "pending", date: "Jun 2, 2026 · 12:00", note: "Order received and confirmed", noteAr: "تم استلام الطلب وتأكيده" },
      { status: "processing", date: "Jun 2, 2026 · 14:30", note: "Packed and ready", noteAr: "تم التعبئة وجاهز للشحن" },
      { status: "shipped", date: "Jun 3, 2026 · 08:20", note: "Shipped via Aramex", noteAr: "تم الشحن عبر أرامكس" },
      { status: "delivered", date: "Jun 4, 2026 · 11:50", note: "Delivered to your address", noteAr: "تم التسليم إلى عنوانك" },
    ],
  },
];

const STATUS_ICONS: Record<OrderStatus, React.ElementType> = {
  pending: Clock,
  processing: Package,
  shipped: Truck,
  delivered: CheckCircle,
};

const STATUS_COLORS: Record<OrderStatus, string> = {
  pending: "#D4852A",
  processing: "#4a90d9",
  shipped: "#7a5c9e",
  delivered: "#4a7c59",
};

function getStatusLabel(status: OrderStatus, tr: any): string {
  const map: Record<OrderStatus, string> = {
    pending: tr.admin.pending,
    processing: tr.admin.processing,
    shipped: tr.admin.shipped,
    delivered: tr.admin.delivered,
  };
  return map[status];
}

function OrderCard({ order, lang, expanded, onToggle }: {
  order: Order; lang: Lang; expanded: boolean; onToggle: () => void;
}) {
  const tr = t[lang];
  const doneIdx = STATUS_STEPS.indexOf(order.status);

  return (
    <motion.div
      layout
      className="rounded-2xl overflow-hidden"
      style={{ border: `1px solid ${order.isActive ? "var(--accent)" : "var(--border)"}`, background: "var(--card)" }}
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
    >
      {/* Order header */}
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-4 px-5 py-4 text-left"
        style={{ background: expanded ? "var(--secondary)" : "transparent" }}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-1 flex-wrap">
            <span
              style={{
                fontFamily: "var(--font-body)",
                color: "var(--primary)",
                fontWeight: 700,
                fontSize: "0.875rem",
              }}
            >
              {order.id}
            </span>
            {/* Active glowing dot */}
            {order.isActive && (
              <span className="flex items-center gap-1.5">
                <span className="relative flex h-2 w-2">
                  <motion.span
                    className="absolute inline-flex h-full w-full rounded-full opacity-75"
                    style={{ background: "var(--accent)" }}
                    animate={{ scale: [1, 2, 1], opacity: [0.75, 0, 0.75] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                  <span
                    className="relative inline-flex rounded-full h-2 w-2"
                    style={{ background: "var(--accent)" }}
                  />
                </span>
                <span
                  className="text-xs uppercase tracking-wider"
                  style={{ color: "var(--accent)", fontFamily: "var(--font-body)", fontWeight: 600 }}
                >
                  {tr.orders.active}
                </span>
              </span>
            )}
            <span
              className="px-2 py-0.5 rounded-full text-xs"
              style={{
                background: `${STATUS_COLORS[order.status]}15`,
                color: STATUS_COLORS[order.status],
                fontFamily: "var(--font-body)",
                fontWeight: 600,
              }}
            >
              {getStatusLabel(order.status, tr)}
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
            <span>{order.date}</span>
            <span>·</span>
            <span>{order.items.length} {lang === "en" ? "item(s)" : "عنصر"}</span>
            <span>·</span>
            <span style={{ color: "var(--foreground)", fontWeight: 600, fontFamily: "var(--font-display)" }}>
              ${order.total}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {order.isActive && (
            <span
              className="hidden sm:block text-xs px-3 py-1.5 rounded-full"
              style={{
                background: "var(--primary)",
                color: "white",
                fontFamily: "var(--font-body)",
                fontWeight: 600,
              }}
            >
              {tr.orders.track}
            </span>
          )}
          <motion.div animate={{ rotate: expanded ? 180 : 0 }} transition={{ duration: 0.25 }}>
            <ChevronDown size={16} style={{ color: "var(--muted-foreground)" }} />
          </motion.div>
        </div>
      </button>

      {/* Expanded content */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 space-y-6">
              {/* Progress bar */}
              <div className="flex items-center gap-0 pt-4">
                {STATUS_STEPS.map((s, i) => {
                  const Icon = STATUS_ICONS[s];
                  const done = i <= doneIdx;
                  const active = i === doneIdx;
                  return (
                    <div key={s} className="flex items-center flex-1">
                      <div className="flex flex-col items-center">
                        <motion.div
                          animate={{
                            background: done ? STATUS_COLORS[order.status] : "var(--muted)",
                            scale: active ? 1.15 : 1,
                          }}
                          className="w-8 h-8 rounded-full flex items-center justify-center"
                        >
                          <Icon size={13} color={done ? "white" : "var(--muted-foreground)"} />
                        </motion.div>
                        <span
                          className="text-xs mt-1.5 hidden sm:block"
                          style={{
                            fontFamily: "var(--font-body)",
                            color: done ? STATUS_COLORS[order.status] : "var(--muted-foreground)",
                            fontWeight: active ? 600 : 400,
                          }}
                        >
                          {getStatusLabel(s, tr)}
                        </span>
                      </div>
                      {i < STATUS_STEPS.length - 1 && (
                        <motion.div
                          className="flex-1 h-0.5 mx-1 rounded-full mb-4 sm:mb-5"
                          animate={{ background: i < doneIdx ? STATUS_COLORS[order.status] : "var(--border)" }}
                          transition={{ duration: 0.4 }}
                        />
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Timeline */}
              <div className="space-y-0">
                {order.timeline.map((event, i) => {
                  const Icon = STATUS_ICONS[event.status];
                  const isLast = i === order.timeline.length - 1;
                  const note = lang === "en" ? event.note : event.noteAr;
                  return (
                    <motion.div
                      key={i}
                      className="flex gap-4"
                      initial={{ opacity: 0, x: lang === "ar" ? 10 : -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.07 }}
                    >
                      <div className="flex flex-col items-center">
                        <div
                          className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 z-10"
                          style={{ background: `${STATUS_COLORS[event.status]}20`, border: `2px solid ${STATUS_COLORS[event.status]}` }}
                        >
                          <Icon size={11} style={{ color: STATUS_COLORS[event.status] }} />
                        </div>
                        {!isLast && (
                          <div className="w-px flex-1 my-1" style={{ background: "var(--border)", minHeight: 24 }} />
                        )}
                      </div>
                      <div className="pb-4 min-w-0 flex-1">
                        <p style={{ fontFamily: "var(--font-body)", color: "var(--foreground)", fontSize: "0.875rem", fontWeight: 500 }}>
                          {note}
                        </p>
                        <p style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", fontSize: "0.75rem", marginTop: "0.2rem" }}>
                          {event.date}
                        </p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {/* Items */}
              <div className="pt-2 border-t space-y-3" style={{ borderColor: "var(--border)" }}>
                {order.items.map((item) => {
                  const name = lang === "en" ? item.name : item.nameAr;
                  return (
                    <div key={item.name} className="flex gap-3 items-center">
                      <div className="w-12 h-12 rounded-lg overflow-hidden shrink-0" style={{ background: "var(--muted)" }}>
                        <img src={item.image} alt={name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p style={{ fontFamily: "var(--font-body)", color: "var(--foreground)", fontSize: "0.875rem" }}>
                          {name}
                        </p>
                        <p style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", fontSize: "0.75rem" }}>
                          ×{item.qty}
                        </p>
                      </div>
                      <span style={{ fontFamily: "var(--font-display)", color: "var(--primary)", fontWeight: 600 }}>
                        ${item.price * item.qty}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export function OrderHistory({ lang }: OrderHistoryProps) {
  const tr = t[lang];
  const [expandedId, setExpandedId] = useState<string | null>("RW-221845");

  return (
    <div className="min-h-screen" style={{ background: "var(--background)" }} dir={tr.dir}>
      <div className="max-w-3xl mx-auto px-6 pt-24 pb-20">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1
            style={{
              fontFamily: "var(--font-display)",
              color: "var(--foreground)",
              fontSize: "clamp(1.8rem, 4vw, 2.5rem)",
              marginBottom: "0.5rem",
            }}
          >
            {tr.orders.title}
          </h1>
          <p style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
            {ORDERS.length} {lang === "en" ? "orders" : "طلبات"}
          </p>
        </motion.div>

        {/* Order cards */}
        <div className="space-y-4">
          {ORDERS.map((order) => (
            <OrderCard
              key={order.id}
              order={order}
              lang={lang}
              expanded={expandedId === order.id}
              onToggle={() => setExpandedId(expandedId === order.id ? null : order.id)}
            />
          ))}
        </div>

        {/* Help strip */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-10 flex items-center justify-center gap-2 text-sm"
          style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
        >
          <MapPin size={13} />
          <span>
            {lang === "en"
              ? "Need help tracking your order? "
              : "تحتاج مساعدة في تتبع طلبك؟ "}
          </span>
          <button
            className="flex items-center gap-1 underline"
            style={{ color: "var(--primary)" }}
          >
            {lang === "en" ? "Contact support" : "تواصل مع الدعم"}
            <ExternalLink size={11} />
          </button>
        </motion.div>
      </div>
    </div>
  );
}
