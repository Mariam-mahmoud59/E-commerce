import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Star, Minus, Plus, ChevronDown, ShieldCheck, Truck, RefreshCw } from "lucide-react";
import { Lang, t } from "./translations";
import { Product } from "./products";

interface ProductDetailProps {
  product: Product;
  lang: Lang;
  onClose: () => void;
  onAddToCart: (p: Product, qty: number) => void;
}

function StarRating({ rating, count }: { rating: number; count: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((s) => (
          <Star
            key={s}
            size={13}
            fill={s <= Math.round(rating) ? "var(--accent)" : "none"}
            stroke={s <= Math.round(rating) ? "var(--accent)" : "var(--muted-foreground)"}
          />
        ))}
      </div>
      <span style={{ color: "var(--muted-foreground)", fontSize: "0.8rem", fontFamily: "var(--font-body)" }}>
        {rating.toFixed(1)} ({count})
      </span>
    </div>
  );
}

export function ProductDetail({ product, lang, onClose, onAddToCart }: ProductDetailProps) {
  const tr = t[lang];
  const [activeTab, setActiveTab] = useState<"details" | "shipping" | "reviews">("details");
  const [qty, setQty] = useState(1);
  const [adding, setAdding] = useState(false);
  const [showSticky, setShowSticky] = useState(false);
  const [openAccordion, setOpenAccordion] = useState<string | null>(null);
  const ctaRef = useRef<HTMLButtonElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const name = lang === "en" ? product.nameEn : product.nameAr;
  const description = lang === "en" ? product.descriptionEn : product.descriptionAr;
  const origin = lang === "en" ? product.origin : product.originAr;
  const material = lang === "en" ? product.material : product.materialAr;

  // Sticky bar appears after scrolling past main CTA
  useEffect(() => {
    const container = scrollRef.current;
    if (!container) return;
    const onScroll = () => {
      const cta = ctaRef.current;
      if (!cta) return;
      const rect = cta.getBoundingClientRect();
      setShowSticky(rect.bottom < 0);
    };
    container.addEventListener("scroll", onScroll);
    return () => container.removeEventListener("scroll", onScroll);
  }, []);

  function handleAdd() {
    if (!product.inStock || adding) return;
    setAdding(true);
    onAddToCart(product, qty);
    setTimeout(() => setAdding(false), 1800);
  }

  const tabs = [
    { key: "details", label: tr.product.details },
    { key: "shipping", label: tr.product.shipping },
    { key: "reviews", label: tr.product.reviews },
  ] as const;

  const accordions = [
    {
      key: "dimensions",
      title: lang === "en" ? "Dimensions & Care" : "الأبعاد والعناية",
      content:
        lang === "en"
          ? "Dimensions vary slightly per piece as each is handmade. Hand wash only with mild soap. Do not soak. Dry in open air away from direct sunlight."
          : "تتفاوت الأبعاد قليلاً لكل قطعة لأنها مصنوعة يدوياً. يُغسل يدوياً فقط بصابون خفيف. لا يُنقع في الماء. جفف في الهواء الطلق بعيداً عن أشعة الشمس المباشرة.",
    },
    {
      key: "artisan",
      title: lang === "en" ? "Artisan Story" : "قصة الحرفي",
      content:
        lang === "en"
          ? "This piece was made by artisans who have practiced their craft for over 30 years. Each creation reflects a lifetime of skill and cultural heritage passed through generations."
          : "صُنعت هذه القطعة من قِبَل حرفيين مارسوا حرفتهم لأكثر من 30 عاماً. تعكس كل قطعة عمراً من المهارة والتراث الثقافي المتوارث عبر الأجيال.",
    },
  ];

  return (
    <motion.div
      className="fixed inset-0 z-50 flex"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      dir={tr.dir}
    >
      {/* Backdrop */}
      <motion.div
        className="absolute inset-0"
        style={{ background: "rgba(44,24,16,0.5)", backdropFilter: "blur(6px)" }}
        onClick={onClose}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
      />

      {/* Panel */}
      <motion.div
        className="relative z-10 ml-auto w-full max-w-4xl h-full flex flex-col shadow-2xl overflow-hidden"
        style={{ background: "var(--background)" }}
        initial={{ x: lang === "ar" ? "-100%" : "100%" }}
        animate={{ x: 0 }}
        exit={{ x: lang === "ar" ? "-100%" : "100%" }}
        transition={{ type: "spring", stiffness: 300, damping: 35 }}
      >
        {/* Close */}
        <div
          className="flex items-center justify-between px-6 py-4 border-b shrink-0"
          style={{ borderColor: "var(--border)" }}
        >
          <p className="text-xs uppercase tracking-widest" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
            {lang === "en" ? product.category : product.categoryAr}
          </p>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-[var(--muted)] transition-colors">
            <X size={18} style={{ color: "var(--foreground)" }} />
          </button>
        </div>

        {/* Scrollable Content */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto">
          <div className="grid md:grid-cols-2 gap-0">
            {/* Image */}
            <div className="relative sticky top-0 h-[50vh] md:h-screen overflow-hidden" style={{ background: "var(--muted)" }}>
              <motion.img
                src={product.image}
                alt={name}
                className="w-full h-full object-cover"
                initial={{ scale: 1.05 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
              />
            </div>

            {/* Info */}
            <div className="p-8 flex flex-col gap-6">
              <div>
                <h1
                  style={{
                    fontFamily: "var(--font-display)",
                    color: "var(--foreground)",
                    fontSize: "clamp(1.5rem, 3vw, 2.2rem)",
                    lineHeight: 1.2,
                    marginBottom: "0.75rem",
                  }}
                >
                  {name}
                </h1>
                <StarRating rating={product.rating} count={product.reviews} />
              </div>

              <div className="flex items-baseline gap-3">
                <span
                  style={{ fontFamily: "var(--font-display)", color: "var(--primary)", fontSize: "2rem", fontWeight: 700 }}
                >
                  ${product.price}
                </span>
                <span className="text-xs uppercase tracking-wider" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
                  {product.inStock ? `✦ ${tr.product.inStock}` : tr.product.outOfStock}
                </span>
              </div>

              {/* Spec pills */}
              <div className="flex flex-wrap gap-2">
                {[
                  { label: tr.product.origin, value: origin },
                  { label: tr.product.material, value: material },
                  { label: tr.product.sku, value: product.sku },
                ].map(({ label, value }) => (
                  <div
                    key={label}
                    className="px-3 py-1.5 rounded-full text-xs"
                    style={{ background: "var(--secondary)", color: "var(--foreground)", fontFamily: "var(--font-body)" }}
                  >
                    <span style={{ color: "var(--muted-foreground)" }}>{label}: </span>
                    {value}
                  </div>
                ))}
              </div>

              {/* Qty + CTA */}
              <div className="flex items-center gap-3">
                <div
                  className="flex items-center gap-3 rounded-full px-4 py-2 border"
                  style={{ borderColor: "var(--border)", background: "var(--secondary)" }}
                >
                  <button
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    className="w-6 h-6 flex items-center justify-center rounded-full transition-colors"
                    style={{ color: "var(--foreground)" }}
                  >
                    <Minus size={13} />
                  </button>
                  <span style={{ fontFamily: "var(--font-body)", fontWeight: 600, minWidth: "1.5rem", textAlign: "center", color: "var(--foreground)" }}>
                    {qty}
                  </span>
                  <button
                    onClick={() => setQty((q) => q + 1)}
                    className="w-6 h-6 flex items-center justify-center rounded-full transition-colors"
                    style={{ color: "var(--foreground)" }}
                  >
                    <Plus size={13} />
                  </button>
                </div>

                <motion.button
                  ref={ctaRef}
                  onClick={handleAdd}
                  disabled={!product.inStock}
                  whileTap={{ scale: 0.97 }}
                  animate={
                    adding
                      ? { backgroundColor: "#4a7c59" }
                      : { backgroundColor: product.inStock ? "var(--accent)" : "var(--muted)" }
                  }
                  transition={{ duration: 0.35 }}
                  className="flex-1 py-3 rounded-full text-sm text-white relative overflow-hidden"
                  style={{
                    fontFamily: "var(--font-body)",
                    fontWeight: 600,
                    cursor: product.inStock ? "pointer" : "not-allowed",
                  }}
                >
                  <AnimatePresence mode="wait">
                    {adding ? (
                      <motion.span
                        key="added"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                        className="flex items-center justify-center gap-2"
                      >
                        ✓ {tr.product.addedToCart}
                      </motion.span>
                    ) : (
                      <motion.span
                        key="add"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -8 }}
                      >
                        {product.inStock ? tr.product.addToCart : tr.product.outOfStock}
                      </motion.span>
                    )}
                  </AnimatePresence>
                </motion.button>
              </div>

              {/* Trust badges */}
              <div className="grid grid-cols-3 gap-3 py-4 border-y" style={{ borderColor: "var(--border)" }}>
                {[
                  { icon: Truck, label: lang === "en" ? "Free shipping\nover $100" : "شحن مجاني\nفوق $100" },
                  { icon: RefreshCw, label: lang === "en" ? "30-day\nreturns" : "إرجاع خلال\n30 يوماً" },
                  { icon: ShieldCheck, label: lang === "en" ? "Authenticity\nguaranteed" : "ضمان\nالأصالة" },
                ].map(({ icon: Icon, label }) => (
                  <div key={label} className="flex flex-col items-center gap-1.5 text-center">
                    <Icon size={18} style={{ color: "var(--accent)" }} />
                    <span
                      className="leading-tight"
                      style={{
                        color: "var(--muted-foreground)",
                        fontFamily: "var(--font-body)",
                        fontSize: "0.68rem",
                        whiteSpace: "pre-line",
                      }}
                    >
                      {label}
                    </span>
                  </div>
                ))}
              </div>

              {/* Tabs */}
              <div>
                <div className="flex gap-0 border-b" style={{ borderColor: "var(--border)" }}>
                  {tabs.map((tab) => (
                    <button
                      key={tab.key}
                      onClick={() => setActiveTab(tab.key)}
                      className="relative px-4 py-2.5 text-sm transition-colors"
                      style={{
                        color: activeTab === tab.key ? "var(--primary)" : "var(--muted-foreground)",
                        fontFamily: "var(--font-body)",
                        fontWeight: activeTab === tab.key ? 600 : 400,
                      }}
                    >
                      {tab.label}
                      {activeTab === tab.key && (
                        <motion.div
                          layoutId="tab-underline"
                          className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full"
                          style={{ background: "var(--primary)" }}
                        />
                      )}
                    </button>
                  ))}
                </div>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -8 }}
                    transition={{ duration: 0.2 }}
                    className="pt-4"
                  >
                    {activeTab === "details" && (
                      <div className="space-y-4">
                        <p
                          className="leading-relaxed"
                          style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", fontSize: "0.9rem" }}
                        >
                          {description}
                        </p>
                        <div className="space-y-2">
                          {accordions.map((acc) => (
                            <div key={acc.key} className="border rounded-lg overflow-hidden" style={{ borderColor: "var(--border)" }}>
                              <button
                                className="w-full flex items-center justify-between px-4 py-3 text-sm"
                                style={{ fontFamily: "var(--font-body)", color: "var(--foreground)", background: "var(--secondary)" }}
                                onClick={() => setOpenAccordion(openAccordion === acc.key ? null : acc.key)}
                              >
                                {acc.title}
                                <motion.div animate={{ rotate: openAccordion === acc.key ? 180 : 0 }}>
                                  <ChevronDown size={14} />
                                </motion.div>
                              </button>
                              <AnimatePresence>
                                {openAccordion === acc.key && (
                                  <motion.div
                                    initial={{ height: 0 }}
                                    animate={{ height: "auto" }}
                                    exit={{ height: 0 }}
                                    transition={{ duration: 0.25 }}
                                    className="overflow-hidden"
                                  >
                                    <p
                                      className="px-4 py-3 text-sm leading-relaxed"
                                      style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                                    >
                                      {acc.content}
                                    </p>
                                  </motion.div>
                                )}
                              </AnimatePresence>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    {activeTab === "shipping" && (
                      <div className="space-y-3" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", fontSize: "0.9rem" }}>
                        <p>
                          {lang === "en"
                            ? "Standard shipping 5–8 business days. Express 2–3 days available. Free shipping on orders over $100."
                            : "الشحن القياسي 5-8 أيام عمل. الشحن السريع 2-3 أيام متاح. شحن مجاني للطلبات فوق $100."}
                        </p>
                        <p>
                          {lang === "en"
                            ? "Returns accepted within 30 days of delivery. Items must be unused and in original packaging."
                            : "يُقبل الإرجاع خلال 30 يوماً من التسليم. يجب أن تكون المنتجات غير مستخدمة وفي عبوتها الأصلية."}
                        </p>
                      </div>
                    )}
                    {activeTab === "reviews" && (
                      <div className="space-y-4">
                        {[
                          { name: "Layla M.", rating: 5, text: lang === "en" ? "Absolutely stunning craftsmanship. Worth every penny." : "حرفية مذهلة تماماً. تستحق كل قرش." },
                          { name: "Omar A.", rating: 5, text: lang === "en" ? "Arrived beautifully packaged. A true work of art." : "وصل معبأً بشكل جميل. عمل فني حقيقي." },
                          { name: "Sarah K.", rating: 4, text: lang === "en" ? "Lovely piece, slightly different shade than photo but still beautiful." : "قطعة رائعة، لون مختلف قليلاً عن الصورة لكنها لا تزال جميلة." },
                        ].map((r) => (
                          <div key={r.name} className="pb-4 border-b last:border-0" style={{ borderColor: "var(--border)" }}>
                            <div className="flex items-center justify-between mb-1">
                              <span style={{ fontFamily: "var(--font-body)", fontWeight: 600, color: "var(--foreground)", fontSize: "0.875rem" }}>{r.name}</span>
                              <div className="flex gap-0.5">
                                {[1,2,3,4,5].map(s => (
                                  <Star key={s} size={10} fill={s<=r.rating?"var(--accent)":"none"} stroke={s<=r.rating?"var(--accent)":"var(--muted-foreground)"} />
                                ))}
                              </div>
                            </div>
                            <p style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", fontSize: "0.85rem" }}>{r.text}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>

        {/* Sticky Add to Cart bar */}
        <AnimatePresence>
          {showSticky && (
            <motion.div
              initial={{ y: 80, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 80, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="absolute bottom-0 left-0 right-0 px-6 py-4 flex items-center justify-between gap-4 border-t shadow-xl"
              style={{
                background: "rgba(250,247,242,0.95)",
                backdropFilter: "blur(12px)",
                borderColor: "var(--border)",
              }}
            >
              <div>
                <p style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontWeight: 600 }}>{name}</p>
                <p style={{ fontFamily: "var(--font-body)", color: "var(--primary)", fontSize: "0.9rem" }}>${product.price}</p>
              </div>
              <motion.button
                onClick={handleAdd}
                whileTap={{ scale: 0.97 }}
                disabled={!product.inStock}
                className="px-8 py-3 rounded-full text-white text-sm"
                style={{
                  background: product.inStock ? "var(--accent)" : "var(--muted)",
                  fontFamily: "var(--font-body)",
                  fontWeight: 600,
                  cursor: product.inStock ? "pointer" : "not-allowed",
                }}
              >
                {tr.product.sticky}
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}
