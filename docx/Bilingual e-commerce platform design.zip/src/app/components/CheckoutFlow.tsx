import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, ArrowLeft, CreditCard, Package, MapPin, Sparkles } from "lucide-react";
import { Lang, t } from "./translations";
import { CartItem } from "./CartSidebar";

interface CheckoutFlowProps {
  lang: Lang;
  items: CartItem[];
  onBack: () => void;
  onSuccess: (orderNumber: string) => void;
}

type Step = 0 | 1 | 2;

const STEP_ICONS = [MapPin, CreditCard, Package];

export function CheckoutFlow({ lang, items, onBack, onSuccess }: CheckoutFlowProps) {
  const tr = t[lang];
  const [step, setStep] = useState<Step>(0);
  const [completed, setCompleted] = useState(false);
  const [orderNum] = useState(() => `RW-${Date.now().toString().slice(-6)}`);
  const subtotal = items.reduce((s, i) => s + i.product.price * i.qty, 0);
  const shipping = subtotal >= 100 ? 0 : 12;
  const total = subtotal + shipping;

  const [shippingData, setShippingData] = useState({
    firstName: "", lastName: "", email: "", phone: "",
    address: "", city: "", country: "", zip: "",
  });
  const [paymentData, setPaymentData] = useState({
    cardNumber: "", expiry: "", cvv: "", name: "",
  });

  const stepTr = tr.checkout;
  const steps = stepTr.steps;

  function handlePlaceOrder() {
    setCompleted(true);
    setTimeout(() => onSuccess(orderNum), 2200);
  }

  if (completed) {
    return (
      <motion.div
        className="min-h-screen flex flex-col items-center justify-center px-6 text-center"
        style={{ background: "var(--background)" }}
        dir={tr.dir}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 18, delay: 0.1 }}
          className="w-24 h-24 rounded-full flex items-center justify-center mb-8"
          style={{ background: "linear-gradient(135deg, var(--primary), var(--accent))" }}
        >
          <Check size={40} color="white" strokeWidth={2.5} />
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.35 }}>
          <h1
            style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "2rem", marginBottom: "1rem" }}
          >
            {stepTr.success.title}
          </h1>
          <p style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)", marginBottom: "2rem", maxWidth: "36ch", margin: "0 auto 2rem" }}>
            {stepTr.success.subtitle}
          </p>
          <div
            className="inline-block px-6 py-3 rounded-xl mb-8"
            style={{ background: "var(--secondary)", color: "var(--foreground)", fontFamily: "var(--font-body)" }}
          >
            <span style={{ color: "var(--muted-foreground)", fontSize: "0.8rem" }}>{stepTr.success.orderNum}: </span>
            <strong style={{ fontFamily: "var(--font-display)", color: "var(--primary)" }}>{orderNum}</strong>
          </div>
        </motion.div>
        <motion.div
          className="flex gap-2 justify-center mt-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="w-2 h-2 rounded-full"
              style={{ background: "var(--accent)" }}
              animate={{ y: [0, -12, 0], opacity: [0.4, 1, 0.4] }}
              transition={{ delay: i * 0.1, duration: 0.8, repeat: Infinity }}
            />
          ))}
        </motion.div>
      </motion.div>
    );
  }

  return (
    <div className="min-h-screen" style={{ background: "var(--background)" }} dir={tr.dir}>
      {/* Top bar */}
      <div
        className="sticky top-0 z-20 border-b px-6 py-4 flex items-center gap-4"
        style={{ background: "rgba(250,247,242,0.95)", backdropFilter: "blur(12px)", borderColor: "var(--border)" }}
      >
        <button onClick={onBack} className="p-2 rounded-full hover:bg-[var(--muted)] transition-colors">
          <ArrowLeft size={18} style={{ color: "var(--foreground)", transform: lang === "ar" ? "scaleX(-1)" : "none" }} />
        </button>
        <h1
          style={{
            fontFamily: "var(--font-display)",
            color: "var(--foreground)",
            fontSize: "1.25rem",
          }}
        >
          {stepTr.title}
        </h1>
      </div>

      {/* Progress Ribbon */}
      <div className="relative h-1.5" style={{ background: "var(--muted)" }}>
        <motion.div
          className="absolute top-0 left-0 h-full rounded-full"
          style={{ background: "linear-gradient(90deg, var(--primary), var(--accent))" }}
          animate={{ width: `${((step + 1) / 3) * 100}%` }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
        />
      </div>

      {/* Step Indicators */}
      <div className="flex justify-center gap-0 mt-6 mb-8 px-6 max-w-lg mx-auto">
        {steps.map((label, i) => {
          const Icon = STEP_ICONS[i];
          const isActive = i === step;
          const isDone = i < step;
          return (
            <div key={label} className="flex items-center flex-1">
              <div className="flex flex-col items-center flex-1">
                <motion.div
                  animate={{
                    background: isDone ? "var(--primary)" : isActive ? "var(--accent)" : "var(--muted)",
                    scale: isActive ? 1.12 : 1,
                  }}
                  transition={{ duration: 0.3 }}
                  className="w-9 h-9 rounded-full flex items-center justify-center mb-2"
                >
                  {isDone ? (
                    <Check size={15} color="white" strokeWidth={2.5} />
                  ) : (
                    <Icon size={15} color={isActive ? "white" : "var(--muted-foreground)"} />
                  )}
                </motion.div>
                <span
                  className="text-xs text-center"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: isActive ? "var(--primary)" : isDone ? "var(--foreground)" : "var(--muted-foreground)",
                    fontWeight: isActive ? 600 : 400,
                  }}
                >
                  {label}
                </span>
              </div>
              {i < 2 && (
                <div
                  className="h-px flex-1 mx-2 mb-6"
                  style={{ background: i < step ? "var(--primary)" : "var(--border)" }}
                />
              )}
            </div>
          );
        })}
      </div>

      <div className="max-w-4xl mx-auto px-6 pb-20 grid md:grid-cols-[1fr_360px] gap-8">
        {/* Main panel */}
        <AnimatePresence mode="wait">
          <motion.div
            key={step}
            initial={{ opacity: 0, x: lang === "ar" ? -30 : 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: lang === "ar" ? 30 : -30 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
          >
            {step === 0 && (
              <div>
                <h2
                  className="mb-6"
                  style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "1.4rem" }}
                >
                  {stepTr.shipping.title}
                </h2>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { key: "firstName", label: stepTr.shipping.firstName },
                    { key: "lastName", label: stepTr.shipping.lastName },
                    { key: "email", label: stepTr.shipping.email, full: true },
                    { key: "phone", label: stepTr.shipping.phone },
                    { key: "address", label: stepTr.shipping.address, full: true },
                    { key: "city", label: stepTr.shipping.city },
                    { key: "country", label: stepTr.shipping.country },
                    { key: "zip", label: stepTr.shipping.zip },
                  ].map(({ key, label, full }) => (
                    <div key={key} className={full ? "col-span-2" : ""}>
                      <label
                        className="block text-xs mb-1.5 uppercase tracking-wide"
                        style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                      >
                        {label}
                      </label>
                      <input
                        value={(shippingData as any)[key]}
                        onChange={(e) => setShippingData((d) => ({ ...d, [key]: e.target.value }))}
                        className="w-full px-4 py-3 rounded-xl border outline-none transition-all focus:ring-2"
                        style={{
                          background: "var(--secondary)",
                          borderColor: "var(--border)",
                          color: "var(--foreground)",
                          fontFamily: "var(--font-body)",
                          fontSize: "0.9rem",
                        }}
                        placeholder={label}
                      />
                    </div>
                  ))}
                </div>
                <motion.button
                  onClick={() => setStep(1)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="mt-8 w-full py-3.5 rounded-full text-white"
                  style={{
                    background: "linear-gradient(135deg, var(--primary), var(--accent))",
                    fontFamily: "var(--font-body)",
                    fontWeight: 600,
                  }}
                >
                  {stepTr.shipping.continue}
                </motion.button>
              </div>
            )}

            {step === 1 && (
              <div>
                <h2
                  className="mb-6"
                  style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "1.4rem" }}
                >
                  {stepTr.payment.title}
                </h2>
                {/* Card visual */}
                <div
                  className="relative rounded-2xl p-6 mb-8 overflow-hidden"
                  style={{
                    background: "linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%)",
                    minHeight: 160,
                  }}
                >
                  <div className="absolute inset-0 opacity-10">
                    {[...Array(6)].map((_, i) => (
                      <div
                        key={i}
                        className="absolute rounded-full border border-white"
                        style={{
                          width: `${80 + i * 40}px`,
                          height: `${80 + i * 40}px`,
                          top: "-20px",
                          right: "-20px",
                          transform: `translate(${i * 15}px, ${i * 10}px)`,
                        }}
                      />
                    ))}
                  </div>
                  <div className="relative">
                    <CreditCard size={28} color="rgba(255,255,255,0.8)" />
                    <p
                      className="mt-4 tracking-[0.2em]"
                      style={{ color: "white", fontFamily: "var(--font-body)", fontSize: "1.1rem" }}
                    >
                      {paymentData.cardNumber || "•••• •••• •••• ••••"}
                    </p>
                    <div className="flex justify-between mt-3">
                      <span style={{ color: "rgba(255,255,255,0.8)", fontSize: "0.8rem", fontFamily: "var(--font-body)" }}>
                        {paymentData.name || (lang === "en" ? "CARD HOLDER" : "حامل البطاقة")}
                      </span>
                      <span style={{ color: "rgba(255,255,255,0.8)", fontSize: "0.8rem", fontFamily: "var(--font-body)" }}>
                        {paymentData.expiry || "MM/YY"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {[
                    { key: "cardNumber", label: stepTr.payment.cardNumber, full: true, placeholder: "1234 5678 9012 3456" },
                    { key: "expiry", label: stepTr.payment.expiry, placeholder: "MM/YY" },
                    { key: "cvv", label: stepTr.payment.cvv, placeholder: "•••" },
                    { key: "name", label: stepTr.payment.name, full: true, placeholder: "As on card" },
                  ].map(({ key, label, full, placeholder }) => (
                    <div key={key} className={full ? "col-span-2" : ""}>
                      <label
                        className="block text-xs mb-1.5 uppercase tracking-wide"
                        style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                      >
                        {label}
                      </label>
                      <input
                        value={(paymentData as any)[key]}
                        onChange={(e) => setPaymentData((d) => ({ ...d, [key]: e.target.value }))}
                        className="w-full px-4 py-3 rounded-xl border outline-none transition-all"
                        style={{
                          background: "var(--secondary)",
                          borderColor: "var(--border)",
                          color: "var(--foreground)",
                          fontFamily: "var(--font-body)",
                          fontSize: "0.9rem",
                        }}
                        placeholder={placeholder}
                      />
                    </div>
                  ))}
                </div>
                <div className="flex gap-4 mt-8">
                  <button
                    onClick={() => setStep(0)}
                    className="px-6 py-3.5 rounded-full border text-sm"
                    style={{ borderColor: "var(--border)", color: "var(--foreground)", fontFamily: "var(--font-body)" }}
                  >
                    {lang === "en" ? "Back" : "رجوع"}
                  </button>
                  <motion.button
                    onClick={() => setStep(2)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex-1 py-3.5 rounded-full text-white"
                    style={{
                      background: "linear-gradient(135deg, var(--primary), var(--accent))",
                      fontFamily: "var(--font-body)",
                      fontWeight: 600,
                    }}
                  >
                    {stepTr.payment.continue}
                  </motion.button>
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <h2
                  className="mb-6"
                  style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontSize: "1.4rem" }}
                >
                  {stepTr.review.title}
                </h2>
                <div
                  className="rounded-2xl p-5 mb-6 space-y-3"
                  style={{ background: "var(--secondary)", border: "1px solid var(--border)" }}
                >
                  <h3
                    className="text-sm uppercase tracking-wider mb-4"
                    style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}
                  >
                    {lang === "en" ? "Shipping to" : "الشحن إلى"}
                  </h3>
                  <p style={{ fontFamily: "var(--font-body)", color: "var(--foreground)", fontSize: "0.9rem" }}>
                    {shippingData.firstName} {shippingData.lastName}
                  </p>
                  <p style={{ fontFamily: "var(--font-body)", color: "var(--muted-foreground)", fontSize: "0.85rem" }}>
                    {shippingData.address}, {shippingData.city}, {shippingData.country}
                  </p>
                  <p style={{ fontFamily: "var(--font-body)", color: "var(--muted-foreground)", fontSize: "0.85rem" }}>
                    {shippingData.email}
                  </p>
                </div>
                <div className="flex gap-4 mt-8">
                  <button
                    onClick={() => setStep(1)}
                    className="px-6 py-3.5 rounded-full border text-sm"
                    style={{ borderColor: "var(--border)", color: "var(--foreground)", fontFamily: "var(--font-body)" }}
                  >
                    {lang === "en" ? "Back" : "رجوع"}
                  </button>
                  <motion.button
                    onClick={handlePlaceOrder}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex-1 py-3.5 rounded-full text-white flex items-center justify-center gap-2"
                    style={{
                      background: "linear-gradient(135deg, var(--primary), var(--accent))",
                      fontFamily: "var(--font-body)",
                      fontWeight: 600,
                    }}
                  >
                    <Sparkles size={15} />
                    {stepTr.review.placeOrder}
                  </motion.button>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Order Summary sidebar */}
        <div
          className="rounded-2xl p-6 h-fit sticky top-24"
          style={{ background: "var(--card)", border: "1px solid var(--border)" }}
        >
          <h3
            className="mb-4 pb-3 border-b"
            style={{
              fontFamily: "var(--font-display)",
              color: "var(--foreground)",
              fontSize: "1.05rem",
              borderColor: "var(--border)",
            }}
          >
            {stepTr.review.orderSummary}
          </h3>
          <div className="space-y-3 mb-5">
            {items.map(({ product, qty }) => {
              const name = lang === "en" ? product.nameEn : product.nameAr;
              return (
                <div key={product.id} className="flex gap-3 items-center">
                  <div className="w-12 h-14 rounded-lg overflow-hidden shrink-0" style={{ background: "var(--muted)" }}>
                    <img src={product.image} alt={name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p
                      className="text-xs leading-tight"
                      style={{ fontFamily: "var(--font-body)", color: "var(--foreground)" }}
                    >
                      {name}
                    </p>
                    <p className="text-xs" style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
                      ×{qty}
                    </p>
                  </div>
                  <span
                    style={{ fontFamily: "var(--font-display)", color: "var(--primary)", fontWeight: 600, fontSize: "0.95rem" }}
                  >
                    ${product.price * qty}
                  </span>
                </div>
              );
            })}
          </div>
          <div className="space-y-2 pt-4 border-t" style={{ borderColor: "var(--border)" }}>
            <div className="flex justify-between text-sm">
              <span style={{ color: "var(--muted-foreground)", fontFamily: "var(--font-body)" }}>
                {stepTr.review.shipping}
              </span>
              <span style={{ color: "var(--foreground)", fontFamily: "var(--font-body)" }}>
                {shipping === 0 ? stepTr.review.free : `$${shipping}`}
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t" style={{ borderColor: "var(--border)" }}>
              <span style={{ fontFamily: "var(--font-display)", color: "var(--foreground)", fontWeight: 600 }}>
                {stepTr.review.total}
              </span>
              <span style={{ fontFamily: "var(--font-display)", color: "var(--primary)", fontWeight: 700, fontSize: "1.2rem" }}>
                ${total}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
