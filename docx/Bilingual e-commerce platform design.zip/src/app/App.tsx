import { useState, useCallback } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Navbar } from "./components/Navbar";
import { Storefront } from "./components/Storefront";
import { ProductDetail } from "./components/ProductDetail";
import { CartSidebar, CartItem } from "./components/CartSidebar";
import { CheckoutFlow } from "./components/CheckoutFlow";
import { AdminDashboard } from "./components/AdminDashboard";
import { OrderHistory } from "./components/OrderHistory";
import { Lang } from "./components/translations";
import { Product } from "./components/products";

type View = "storefront" | "checkout" | "admin" | "orders";

export default function App() {
  {/* MARKER-MAKE-KIT-INVOKED */}
  const [lang, setLang] = useState<Lang>("en");
  const [langTransitioning, setLangTransitioning] = useState(false);
  const [view, setView] = useState<View>("storefront");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const cartCount = cartItems.reduce((s, i) => s + i.qty, 0);

  const handleLangToggle = useCallback(() => {
    if (langTransitioning) return;
    setLangTransitioning(true);
    setTimeout(() => {
      setLang((l) => (l === "en" ? "ar" : "en"));
      setLangTransitioning(false);
    }, 280);
  }, [langTransitioning]);

  const handleAddToCart = useCallback((product: Product, qty = 1) => {
    setCartItems((prev) => {
      const existing = prev.find((i) => i.product.id === product.id);
      if (existing) {
        return prev.map((i) =>
          i.product.id === product.id ? { ...i, qty: i.qty + qty } : i
        );
      }
      return [...prev, { product, qty }];
    });
  }, []);

  const handleRemoveFromCart = useCallback((id: string) => {
    setCartItems((prev) => prev.filter((i) => i.product.id !== id));
  }, []);

  const handleCheckout = useCallback(() => {
    setCartOpen(false);
    setView("checkout");
  }, []);

  const handleOrderSuccess = useCallback(() => {
    setCartItems([]);
    setView("orders");
  }, []);

  const handleNavigate = useCallback((v: string) => {
    setView(v as View);
    setSelectedProduct(null);
  }, []);

  const pageVariants = {
    initial: (direction: number) => ({ opacity: 0, x: direction * 40 }),
    animate: { opacity: 1, x: 0 },
    exit: (direction: number) => ({ opacity: 0, x: direction * -40 }),
  };

  const langSlideVariants = {
    initial: { opacity: 0, x: lang === "ar" ? -60 : 60, scaleX: 0.97 },
    animate: { opacity: 1, x: 0, scaleX: 1 },
    exit: { opacity: 0, x: lang === "ar" ? 60 : -60, scaleX: 0.97 },
  };

  return (
    <div className="min-h-screen" style={{ background: "var(--background)" }}>
      {/* ── Language flip wrapper ── */}
      <AnimatePresence mode="wait">
        <motion.div
          key={lang}
          variants={langSlideVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
          style={{ transformOrigin: "center" }}
        >
          {/* Navbar — always visible except full-screen checkout */}
          {view !== "checkout" && (
            <Navbar
              lang={lang}
              onLangToggle={handleLangToggle}
              cartCount={cartCount}
              onCartOpen={() => setCartOpen(true)}
              currentView={view}
              onNavigate={handleNavigate}
            />
          )}

          {/* ── Page content ── */}
          <AnimatePresence mode="wait" custom={lang === "ar" ? -1 : 1}>
            {view === "storefront" && (
              <motion.div
                key="storefront"
                custom={lang === "ar" ? -1 : 1}
                variants={pageVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              >
                <Storefront
                  lang={lang}
                  onProductSelect={setSelectedProduct}
                  onAddToCart={handleAddToCart}
                />
              </motion.div>
            )}

            {view === "admin" && (
              <motion.div
                key="admin"
                custom={lang === "ar" ? -1 : 1}
                variants={pageVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              >
                <div style={{ paddingTop: "4rem" }}>
                  <AdminDashboard lang={lang} />
                </div>
              </motion.div>
            )}

            {view === "orders" && (
              <motion.div
                key="orders"
                custom={lang === "ar" ? -1 : 1}
                variants={pageVariants}
                initial="initial"
                animate="animate"
                exit="exit"
                transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              >
                <OrderHistory lang={lang} />
              </motion.div>
            )}

            {view === "checkout" && (
              <motion.div
                key="checkout"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.25 }}
              >
                <CheckoutFlow
                  lang={lang}
                  items={cartItems}
                  onBack={() => setView("storefront")}
                  onSuccess={handleOrderSuccess}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </AnimatePresence>

      {/* ── Product Detail overlay ── */}
      <AnimatePresence>
        {selectedProduct && view === "storefront" && (
          <ProductDetail
            key={selectedProduct.id}
            product={selectedProduct}
            lang={lang}
            onClose={() => setSelectedProduct(null)}
            onAddToCart={(p, qty) => {
              handleAddToCart(p, qty);
            }}
          />
        )}
      </AnimatePresence>

      {/* ── Cart sidebar ── */}
      <CartSidebar
        lang={lang}
        items={cartItems}
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        onRemove={handleRemoveFromCart}
        onCheckout={handleCheckout}
      />
    </div>
  );
}
